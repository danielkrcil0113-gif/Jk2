import{l as o,a as r}from"../chunks/x-BRVAJC.js";export{o as load_css,r as start};
